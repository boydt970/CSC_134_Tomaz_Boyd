//@author: Tomaz Boyd
//@date: 09/1/2025
//@purpose: This program calculates the product of 2 floating-point values

//include the iostream directive
#include <iostream>

//use the standard namespace 
using namespace std;

//define the main() function/method
int main()
{
    double num1 = 5.5;//5.5 vaule as a float
    double num2 = 10.2;//10.2 value as a float
    double product = num1 + num2;//the adding of both values
    //prints results from 2 numbers above
    std::cout << product << std::endl;

    return 0;
}