//@author: Tomaz Boyd
//@date: 08/31/2025
//@purpose: This program prints Hi!
//include the iostream directive
#include <iostream>

//use the standard namespace 
using namespace std;

//define the main() function/method
int main()
{
   char H, I, x;// store character variable
   H = 'H';
   I = 'i';
   x = '!';
   //prints Hi!
   cout << H << I << x << endl;
   
    return 0;
}