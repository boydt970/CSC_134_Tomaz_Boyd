/* This is my first C++ program */
/*downloaded visual studio*/