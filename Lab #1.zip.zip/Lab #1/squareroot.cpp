//@author: Tomaz Boyd
//@date: 08/27/2025
//@purpose: This program calculates the product of two numbers

//include the iostream directive
#include <iostream>
#include <cmath>
//use the standard namespace 
using namespace std;

//define the main() function/method
int main()
{
    double num1 = 90;
    double SquareRoot = sqrt(num1);
    //prints comment from 2 numbers above
    std::cout << "The Squareroot of " << num1 << " is " << SquareRoot << std::endl;

    return 0;
}